# The Weather App  
[![Netlify Status](https://api.netlify.com/api/v1/badges/596334bc-2390-4ba2-8399-1be5183e8b3e/deploy-status)](https://app.netlify.com/sites/weather-application-pwa/deploys)


Visit the weather app here: [Weather App](https://weather-application-pwa.netlify.app/)

Check out my articles on **DEV** to get great insights about this project.

- [Learn React by building a Weather App](https://dev.to/kgprajwal/learn-react-by-building-a-weather-app-3229)
- [Building a Progressive Web App and Deploying it](https://dev.to/kgprajwal/building-a-progressive-web-app-and-deploying-it-10p7)