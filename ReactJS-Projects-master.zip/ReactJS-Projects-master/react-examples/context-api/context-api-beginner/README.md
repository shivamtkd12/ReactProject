# Context API

https://reactjs.org/docs/context.html