import React from 'react';


// https://reactjs.org/docs/context.html#reactcreatecontext
// This is my context
export default React.createContext();