import React from 'react'

const Cart = () => {
    return (
        <div>
            <h1>Rendered by Cart Component</h1>
        </div>
    )
}

export default Cart