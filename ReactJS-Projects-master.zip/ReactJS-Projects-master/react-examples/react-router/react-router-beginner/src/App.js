import React from 'react';
import './App.css';

function App() {
  return (
    <div>
      <h1>Rendered by App Component</h1>
    </div>
  );
}

export default App;
