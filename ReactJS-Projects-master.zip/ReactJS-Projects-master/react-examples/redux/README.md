# Redux

#### Principles

1) Single source of truth
2) State is read-only
3) Changes are made with pure functions

#### Keywords:

1) Central State
2) Store
3) Actions
4) Reducers
5) Data flow