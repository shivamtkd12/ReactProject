# Github Repo Search App

An app built to easily find github by its users and explore their repos. Built using React with Firebase authentication.